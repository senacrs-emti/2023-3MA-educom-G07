package com.example.numerix20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Hexagono extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hexagono);
    }
    public void numerix_img(View view){
        Intent in = new Intent(Hexagono.this, MainActivity.class);
        startActivity(in);
    }
    public void voltar(View view){
        Intent in = new Intent(Hexagono.this, Poligonos.class);
        startActivity(in);
    }
}
