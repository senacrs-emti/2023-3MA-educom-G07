package com.example.numerix20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Poligonos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_poligonos);

    }
    public void triangulo(View view){
        Intent in = new Intent(Poligonos.this, Triangulo.class);
        startActivity(in);
    }
    public void pentagono(View view){
        Intent in = new Intent(Poligonos.this, Pentagono.class);
        startActivity(in);
    }
    public void hexagono(View view){
        Intent in = new Intent(Poligonos.this, Hexagono.class);
        startActivity(in);
    }
    public void heptagono(View view){
        Intent in = new Intent(Poligonos.this, Heptagono.class);
        startActivity(in);
    }
    public void numerix_img(View view){
        Intent in = new Intent(Poligonos.this, MainActivity.class);
        startActivity(in);
    }



}