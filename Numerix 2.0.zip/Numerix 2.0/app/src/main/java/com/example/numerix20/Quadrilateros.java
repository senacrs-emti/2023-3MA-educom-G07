package com.example.numerix20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Quadrilateros extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quadrilateros);

    }
    public void paralelogramo(View view){
        Intent in = new Intent(Quadrilateros.this, Paralelograma.class);
        startActivity(in);
    }
    public void retangulo(View view){
        Intent in = new Intent(Quadrilateros.this, Retangulo.class);
        startActivity(in);
    }

    public void quadrado(View view){
        Intent in = new Intent(Quadrilateros.this, Quadrado.class);
        startActivity(in);
    }

    public void lozango(View view){
        Intent in = new Intent(Quadrilateros.this, Lozango.class);
        startActivity(in);
    }
    public void numerix_img(View view){
        Intent in = new Intent(Quadrilateros.this, MainActivity.class);
        startActivity(in);
    }


}