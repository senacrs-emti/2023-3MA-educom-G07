package com.example.numerix20;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Geometria extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geometria);

    }
    public void triangulo(View view){
        Intent in = new Intent(Geometria.this, Triangulo.class);
        startActivity(in);
    }

    public void quadrado(View view){
        Intent in = new Intent(Geometria.this, Quadrado.class);
        startActivity(in);
    }

    public void retangulo(View view){
        Intent in = new Intent(Geometria.this, Retangulo.class);
        startActivity(in);
    }

    public void circulo(View view){
        Intent in = new Intent(Geometria.this, Circulo.class);
        startActivity(in);
    }

    public void numerix_img(View view){
        Intent in = new Intent(Geometria.this, MainActivity.class);
        startActivity(in);
    }
}