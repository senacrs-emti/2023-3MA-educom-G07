package com.example.numerix20;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Geometria extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geometria);

    }
    public void triangulo(View view){
        Intent in = new Intent(Geometria.this, Triangulos.class);
        startActivity(in);
    }

    public void quadrilateros(View view){
        Intent in = new Intent(Geometria.this, Quadrilateros.class);
        startActivity(in);
    }

    public void poligonos(View view){
        Intent in = new Intent(Geometria.this, Poligonos.class);
        startActivity(in);
    }

    public void circulo(View view){
        Intent in = new Intent(Geometria.this, Circulo.class);
        startActivity(in);
    }

    public void numerix_img(View view){
        Intent in = new Intent(Geometria.this, MainActivity.class);
        startActivity(in);
    }
}