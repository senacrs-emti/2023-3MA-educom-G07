package com.example.numerix20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Triangulo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulo);
    }
    public void numerix_img(View view){
        Intent in = new Intent(Triangulo.this, MainActivity.class);
        startActivity(in);
    }
    public void voltar(View view){
        Intent in = new Intent(Triangulo.this, Poligonos.class);
        startActivity(in);
    }
}