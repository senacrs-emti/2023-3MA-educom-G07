package com.example.numerix20;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Isosceles extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trisosceles);
    }
    public void numerix_img(View view){
        Intent in = new Intent(Isosceles.this, MainActivity.class);
        startActivity(in);
    }
}