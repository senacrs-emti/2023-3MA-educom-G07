package com.example.numerix20;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Triangulos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_triangulos);

    }
    public void isosceles(View view){
        Intent in = new Intent(Triangulos.this, Isosceles.class);
        startActivity(in);
    }
    public void equilatero(View view){
        Intent in = new Intent(Triangulos.this, Equilatero.class);
        startActivity(in);
    }


}