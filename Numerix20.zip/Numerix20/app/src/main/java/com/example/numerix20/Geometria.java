package com.example.numerix20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Geometria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geometria);
    }
    public void triangulo(View view){
        Intent in = new Intent(Geometria.this, Triangulo.class);
        startActivity(in);
    }
    public void numerix_img(View view){
        Intent in = new Intent(Geometria.this, MainActivity.class);
        startActivity(in);
    }
}